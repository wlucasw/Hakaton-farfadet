﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Break : MonoBehaviour
{
    
    public int minForce;//The Minimum Force Required To Break The Object
    public GameObject broken;//The Broken Object
    public GameObject real;

    void OnCollisionEnter(Collision col)//When Object Collides
    {
        print("The Magnitude Was " + col.relativeVelocity.magnitude.ToString());//Print Out The Magnitude Of The Collision
        if (col.relativeVelocity.magnitude >= minForce && col.gameObject.tag == "Objects")//If The magnitude Of The Collision Is Equal or Greater Than The Minimum Force Required TO Break It
        {
            Shatter();
        }
    }
    void Shatter()
    {
        //Vector3 pos = new Vector3(7.3f, -15.7f, 6.3f);
        
        
        GameObject obj = Instantiate(broken, transform.position, transform.rotation) as GameObject;//Instantiate The Broken Version Of The Object At The Current Position
        
        //obj.transform.position = this.gameObject.transform.position;
        //obj.transform.localPosition = pos;
        
        Destroy(real);//And Delete the Current GameObject
    }
    
}
